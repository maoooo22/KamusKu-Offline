# KamusKu Offline — PWA Starter

Aplikasi kamus Inggris–Indonesia offline-first berbasis PWA.

## Fitur yang sudah dibuat
- Pencarian dua arah dengan pencarian sebagian kata.
- Detail kata, jenis kata, contoh kalimat, tombol TTS.
- Favorit dan riwayat tersimpan di localStorage.
- Word of the Day, kuis pilihan ganda 10 soal, skor dan statistik.
- Dark mode, kecepatan TTS, backup/restore JSON.
- Service worker untuk cache aplikasi dan database.

## Instalasi Android (PWA)
1. Upload isi folder ini ke hosting statis HTTPS (misalnya GitHub Pages/Netlify).
2. Buka URL di Chrome Android saat online.
3. Pilih menu ⋮ → Install app / Tambahkan ke layar utama.
4. Buka aplikasi sekali agar service worker menyimpan semua aset dan database.
5. Aktifkan mode pesawat dan uji pencarian.

Service worker membutuhkan HTTPS atau localhost. Jangan hanya membuka file index.html langsung dari file manager.

## Jalankan lokal
Di komputer, dari folder proyek jalankan `python -m http.server 8080`, lalu buka `http://localhost:8080`.

## Batasan versi ini
- Database berisi 500 entri awal, belum memenuhi target 10.000 entri tervalidasi.
- Ini PWA yang dapat dipasang dari browser, bukan APK native hasil kompilasi.
- APK native membutuhkan Android Studio/SDK/Gradle dan proses build pada lingkungan Android.
- TTS menggunakan speechSynthesis browser/perangkat; suara English harus tersedia di Android.
- Contoh kalimat bersifat contoh penggunaan dan tidak selalu disertai terjemahan.
