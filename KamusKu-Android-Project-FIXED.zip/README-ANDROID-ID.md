# KamusKu Offline — Android APK project

Project Android Studio (Kotlin + WebView) yang membungkus aplikasi kamus web menjadi APK. Konten web dan database disimpan di `app/src/main/assets/www`, sehingga pencarian kamus tidak memerlukan internet. Android Text-to-Speech disediakan melalui bridge native.

## Build APK otomatis lewat GitHub (bisa dari HP)
1. Buat atau buka repository GitHub.
2. Ekstrak ZIP ini, lalu upload **semua isi folder ini** ke root repository (bukan folder pembungkus ZIP). Pastikan folder `.github/workflows` ikut ter-upload.
3. Buka tab **Actions** → workflow **Build KamusKu APK** → **Run workflow** (atau tunggu build otomatis setelah push ke `main`/`master`).
4. Tunggu sampai workflow hijau/sukses.
5. Buka hasil run tersebut, bagian **Artifacts**, lalu unduh `KamusKu-Offline-debug-apk`.
6. Ekstrak ZIP artifact dan install `app-debug.apk` di Android. Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

## Build lokal lewat Android Studio
- Buka folder proyek ini sebagai project Android.
- Gunakan JDK 17 dan Android SDK Platform 35.
- Jalankan **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Output debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Ini debug APK untuk instalasi/pengujian pribadi, belum APK release bertanda tangan untuk distribusi Play Store.
- Database yang dibawa saat ini berisi 500 entri starter, belum 10.000 entri.
- Uji restore/backup, suara TTS, dan perilaku offline pada perangkat Android sebelum dipakai rutin.
